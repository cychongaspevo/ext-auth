from django.apps import AppConfig


class ExtAuthConfig(AppConfig):
    name = 'ext_auth'
    verbose_name = "External Auth"